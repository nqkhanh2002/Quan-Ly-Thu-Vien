/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lm_model;

/**
 *
 * @author Brown.D
 */
public class mdl_theloai {
    
    private int MATHELOAI;
    private String TENTHELOAI;

    public int getMATHELOAI() {
        return MATHELOAI;
    }

    public void setMATHELOAI(int MATHELOAI) {
        this.MATHELOAI = MATHELOAI;
    }

    public String getTENTHELOAI() {
        return TENTHELOAI;
    }

    public void setTENTHELOAI(String TENTHELOAI) {
        this.TENTHELOAI = TENTHELOAI;
    }

}
