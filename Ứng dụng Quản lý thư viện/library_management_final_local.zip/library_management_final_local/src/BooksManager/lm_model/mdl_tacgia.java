/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lm_model;

/**
 *
 * @author Brown.D
 */
public class mdl_tacgia {
    
    private int MATACGIA;
    private String TENTACGIA;

    public int getMATACGIA() {
        return MATACGIA;
    }

    public void setMATACGIA(int MATACGIA) {
        this.MATACGIA = MATACGIA;
    }

    public String getTENTACGIA() {
        return TENTACGIA;
    }

    public void setTENTACGIA(String TENTACGIA) {
        this.TENTACGIA = TENTACGIA;
    }
    
}
